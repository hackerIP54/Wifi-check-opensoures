#!/usr/bin/env bash
set -euo pipefail

SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK" ]]; then
  echo "Set ANDROID_SDK_ROOT or ANDROID_HOME first."
  exit 1
fi

PLATFORM="$SDK/platforms/android-35/android.jar"
TOOLS="$SDK/build-tools/34.0.0"
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/manual-build"

rm -rf "$BUILD"
mkdir -p "$BUILD/classes" "$BUILD/gen" "$BUILD/dex"

"$TOOLS/aapt2" compile --dir "$ROOT/app/src/main/res" -o "$BUILD/resources.zip"
"$TOOLS/aapt2" link -o "$BUILD/base-unsigned.apk" -I "$PLATFORM" \
  --manifest "$ROOT/app/src/main/AndroidManifest.xml" --java "$BUILD/gen" \
  --min-sdk-version 26 --target-sdk-version 35 --version-code 1 --version-name 1.0.0 \
  "$BUILD/resources.zip"

SOURCES=(
  "$BUILD/gen/com/starcode/livenet/R.java"
  "$ROOT/app/src/main/java/com/starcode/livenet/GraphView.java"
  "$ROOT/app/src/main/java/com/starcode/livenet/MainActivity.java"
)
if command -v javac >/dev/null 2>&1; then
  javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$PLATFORM" \
    -d "$BUILD/classes" "${SOURCES[@]}"
elif [[ -n "${ECJ_JAR:-}" && -f "$ECJ_JAR" ]]; then
  java -jar "$ECJ_JAR" -encoding UTF-8 -source 1.8 -target 1.8 \
    -bootclasspath "$PLATFORM" -d "$BUILD/classes" "${SOURCES[@]}"
else
  echo "Install a JDK with javac, or set ECJ_JAR to an Eclipse compiler JAR."
  exit 1
fi

mapfile -t CLASSES < <(find "$BUILD/classes" -name '*.class' -type f)
"$TOOLS/d8" --lib "$PLATFORM" --min-api 26 --output "$BUILD/dex" "${CLASSES[@]}"
cp "$BUILD/base-unsigned.apk" "$BUILD/with-dex.apk"
(cd "$BUILD/dex" && zip -q -u "$BUILD/with-dex.apk" classes.dex)
"$TOOLS/zipalign" -f 4 "$BUILD/with-dex.apk" "$BUILD/aligned.apk"

KEYSTORE="$BUILD/debug.keystore"
keytool -genkeypair -keystore "$KEYSTORE" -storepass android -keypass android \
  -alias androiddebugkey -dname "CN=Android Debug,O=STARCODE,C=DE" \
  -keyalg RSA -keysize 2048 -validity 10000 >/dev/null 2>&1
"$TOOLS/apksigner" sign --ks "$KEYSTORE" --ks-pass pass:android \
  --key-pass pass:android --out "$ROOT/LiveNetMonitor-Android.apk" "$BUILD/aligned.apk"
"$TOOLS/apksigner" verify --verbose "$ROOT/LiveNetMonitor-Android.apk"
echo "Built: $ROOT/LiveNetMonitor-Android.apk"
