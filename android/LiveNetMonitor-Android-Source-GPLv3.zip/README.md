# STARCODE LiveNet Monitor for Android

Native Android network and system monitor by **starcode-bom & hackerIP54**.

Official website and downloads: https://wific-install.starcode-bom.com

## Features

- TCP latency measurement to `1.1.1.1:443`
- Live download and upload throughput
- Ping history, average, minimum, maximum, jitter, and packet loss
- Local IPv4 address, connection type, and estimated link speed
- RAM usage and device uptime
- Pause and reset controls
- Automatic German/English localization
- Animated startup screen
- No advertising, tracking, account, or third-party app libraries

## License

Copyright © 2026 starcode-bom & hackerIP54.

This project is free software licensed under the **GNU General Public License version 3 only**. See `LICENSE`.

## Build

Open the project in Android Studio, or install Android platform 35 and build-tools 34.0.0 and run:

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
chmod +x build-manual.sh
./build-manual.sh
```

The script creates a locally signed, installable APK. For store publishing, configure your own release signing key and keep it private.
