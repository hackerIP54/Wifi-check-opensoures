/*
 * STARCODE LiveNet Monitor for Android
 * Copyright (C) 2026 starcode-bom & hackerIP54
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3.
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.starcode.livenet;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(9, 14, 24);
    private static final int SURFACE = Color.rgb(21, 29, 43);
    private static final int SURFACE_2 = Color.rgb(29, 39, 56);
    private static final int TEXT = Color.rgb(244, 247, 255);
    private static final int MUTED = Color.rgb(147, 161, 184);
    private static final int MINT = Color.rgb(68, 224, 164);
    private static final int BLUE = Color.rgb(101, 169, 255);
    private static final int VIOLET = Color.rgb(173, 140, 255);

    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status, pingValue, pingDetail, downValue, downDetail, upValue, upDetail;
    private TextView localIp, networkType, packetLoss, jitter, linkSpeed, ramUsage, uptime;
    private TextView pauseButton;
    private GraphView graph;
    private volatile boolean paused;
    private long attempts, successes, minPing = Long.MAX_VALUE, maxPing, sumPing, jitterSum, previousPing;
    private long lastRx = -1, lastTx = -1, lastMeasureTime, peakDown, peakUp;

    @Override protected void onCreate(Bundle state) {
        String savedLanguage = getSharedPreferences("settings", MODE_PRIVATE).getString("language", "");
        if (!savedLanguage.isEmpty()) {
            Locale locale = new Locale(savedLanguage); Locale.setDefault(locale);
            Configuration configuration = new Configuration(getResources().getConfiguration());
            configuration.setLocale(locale); getResources().updateConfiguration(configuration, getResources().getDisplayMetrics());
        }
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(BG); window.setNavigationBarColor(BG);
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(BG); setContentView(root);
        root.addView(buildDashboard(), new FrameLayout.LayoutParams(-1, -1));
        showSplash(root);
        executor.scheduleAtFixedRate(new Runnable() {
            @Override public void run() { measure(); }
        }, 300, 1000, TimeUnit.MILLISECONDS);
    }

    private View buildDashboard() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout body = column(); body.setPadding(dp(16), dp(18), dp(16), dp(30)); scroll.addView(body);

        LinearLayout header = row(); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = label("S", 25, Color.rgb(7, 41, 31), true); logo.setGravity(Gravity.CENTER); logo.setBackground(round(MINT, 16));
        header.addView(logo, size(54, 54));
        LinearLayout brand = column(); brand.setPadding(dp(12), 0, 0, 0);
        brand.addView(label("STARCODE", 22, TEXT, true)); brand.addView(label(getString(R.string.subtitle), 12, MUTED, false));
        header.addView(brand, weight()); body.addView(header);

        LinearLayout statusRow = row(); statusRow.setGravity(Gravity.CENTER_VERTICAL); statusRow.setPadding(0, dp(16), 0, dp(12));
        status = label(getString(R.string.waiting), 11, MINT, true); status.setGravity(Gravity.CENTER); status.setBackground(round(Color.rgb(24, 65, 54), 18));
        statusRow.addView(status, new LinearLayout.LayoutParams(0, dp(38), 1));
        TextView language = action("DE/EN"); language.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { toggleLanguage(); }}); statusRow.addView(language, smallButtonParams());
        pauseButton = action(getString(R.string.pause)); pauseButton.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { togglePause(); }}); statusRow.addView(pauseButton, buttonParams());
        TextView reset = action(getString(R.string.reset)); reset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { resetStats(); }}); statusRow.addView(reset, buttonParams());
        body.addView(statusRow);

        LinearLayout cards = row();
        LinearLayout ping = metricCard(R.string.ping, MINT); pingValue = valueText("– ms"); pingDetail = detailText(getString(R.string.waiting)); ping.addView(pingValue); ping.addView(pingDetail); cards.addView(ping, cardWeight(0, 5));
        LinearLayout down = metricCard(R.string.download, BLUE); downValue = valueText("0 bit/s"); downDetail = detailText(getString(R.string.peak) + " 0 bit/s"); down.addView(downValue); down.addView(downDetail); cards.addView(down, cardWeight(dp(7), 5));
        LinearLayout up = metricCard(R.string.upload, VIOLET); upValue = valueText("0 bit/s"); upDetail = detailText(getString(R.string.peak) + " 0 bit/s"); up.addView(upValue); up.addView(upDetail); cards.addView(up, cardWeight(dp(7), 5));
        body.addView(cards);

        LinearLayout graphCard = panel(); graphCard.setPadding(dp(14), dp(14), dp(14), dp(10));
        graphCard.addView(label(getString(R.string.ping_history), 11, MUTED, true)); graph = new GraphView(this); graphCard.addView(graph, new LinearLayout.LayoutParams(-1, dp(150)));
        LinearLayout.LayoutParams graphParams = new LinearLayout.LayoutParams(-1, -2); graphParams.topMargin = dp(10); body.addView(graphCard, graphParams);

        LinearLayout info = row();
        LinearLayout connection = panel(); connection.addView(sectionTitle(R.string.connection));
        localIp = infoLine(connection, R.string.local_ip); networkType = infoLine(connection, R.string.network_type); packetLoss = infoLine(connection, R.string.packet_loss); jitter = infoLine(connection, R.string.jitter);
        info.addView(connection, cardWeight(0, 1));
        LinearLayout system = panel(); system.addView(sectionTitle(R.string.system));
        linkSpeed = infoLine(system, R.string.link_speed); ramUsage = infoLine(system, R.string.ram_usage); uptime = infoLine(system, R.string.device_uptime); infoLineStatic(system, R.string.ping_target, "1.1.1.1:443");
        info.addView(system, cardWeight(dp(8), 1));
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(-1, -2); infoParams.topMargin = dp(10); body.addView(info, infoParams);

        TextView license = action(getString(R.string.license_button)); license.setGravity(Gravity.CENTER); license.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showLicense(); }});
        LinearLayout.LayoutParams licenseParams = new LinearLayout.LayoutParams(-1, dp(44)); licenseParams.topMargin = dp(14); body.addView(license, licenseParams);
        TextView copyright = label(getString(R.string.copyright), 10, MUTED, false); copyright.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams copyrightParams = new LinearLayout.LayoutParams(-1, -2); copyrightParams.topMargin = dp(14); body.addView(copyright, copyrightParams);
        return scroll;
    }

    private void showSplash(final FrameLayout root) {
        final LinearLayout splash = column(); splash.setGravity(Gravity.CENTER); splash.setBackgroundColor(BG);
        TextView logo = label("S", 44, Color.rgb(7, 41, 31), true); logo.setGravity(Gravity.CENTER); logo.setBackground(round(MINT, 28)); splash.addView(logo, size(94, 94));
        TextView brand = label("STARCODE", 31, TEXT, true); brand.setGravity(Gravity.CENTER); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = dp(20); splash.addView(brand, bp);
        TextView by = label("starcode-bom & hackerIP54", 12, MUTED, false); by.setGravity(Gravity.CENTER); splash.addView(by);
        ProgressBar progress = new ProgressBar(this); progress.setIndeterminate(true); progress.getIndeterminateDrawable().setTint(MINT); LinearLayout.LayoutParams pp = size(44, 44); pp.topMargin = dp(30); splash.addView(progress, pp);
        TextView loading = label(getString(R.string.loading), 13, MUTED, false); loading.setGravity(Gravity.CENTER); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(12); splash.addView(loading, lp);
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                ObjectAnimator a = ObjectAnimator.ofFloat(splash, View.ALPHA, 1f, 0f);
                a.setDuration(450); a.setInterpolator(new DecelerateInterpolator());
                a.addListener(new android.animation.AnimatorListenerAdapter(){
                    @Override public void onAnimationEnd(android.animation.Animator animation){ root.removeView(splash); }
                });
                a.start();
            }
        }, 1700);
    }

    private void measure() {
        if (paused) return;
        long start = SystemClock.elapsedRealtime(); long ping = -1;
        Socket socket = null;
        try { socket = new Socket(); socket.connect(new InetSocketAddress("1.1.1.1", 443), 850); ping = SystemClock.elapsedRealtime() - start; }
        catch (Exception ignored) {}
        finally { if (socket != null) try { socket.close(); } catch (Exception ignored) {} }
        attempts++;
        if (ping >= 0) { successes++; sumPing += ping; minPing = Math.min(minPing, ping); maxPing = Math.max(maxPing, ping); if (previousPing > 0) jitterSum += Math.abs(ping - previousPing); previousPing = ping; }
        long now = SystemClock.elapsedRealtime(), rx = TrafficStats.getTotalRxBytes(), tx = TrafficStats.getTotalTxBytes();
        long secondsMs = lastMeasureTime == 0 ? 0 : now - lastMeasureTime;
        long down = secondsMs > 0 && lastRx >= 0 && rx >= lastRx ? (rx - lastRx) * 1000 / secondsMs : 0;
        long up = secondsMs > 0 && lastTx >= 0 && tx >= lastTx ? (tx - lastTx) * 1000 / secondsMs : 0;
        peakDown = Math.max(peakDown, down); peakUp = Math.max(peakUp, up); lastRx = rx; lastTx = tx; lastMeasureTime = now;
        final long fp = ping, fd = down, fu = up; final String ip = findLocalIp(); final NetworkInfo ni = getNetworkInfo();
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        final int ram = mi.totalMem > 0 ? (int)((mi.totalMem - mi.availMem) * 100 / mi.totalMem) : 0;
        runOnUiThread(new Runnable() { @Override public void run() { update(fp, fd, fu, ip, ni, ram); }});
    }

    private void update(long ping, long down, long up, String ip, NetworkInfo ni, int ram) {
        status.setText(ping >= 0 ? R.string.connected : R.string.offline); status.setTextColor(ping >= 0 ? MINT : Color.rgb(255, 112, 132));
        pingValue.setText(ping >= 0 ? ping + " ms" : "– ms");
        long avg = successes == 0 ? 0 : sumPing / successes;
        pingDetail.setText("Ø " + avg + " · " + (minPing == Long.MAX_VALUE ? 0 : minPing) + "–" + maxPing + " ms");
        downValue.setText(formatRate(down)); upValue.setText(formatRate(up));
        downDetail.setText(getString(R.string.peak) + " " + formatRate(peakDown)); upDetail.setText(getString(R.string.peak) + " " + formatRate(peakUp));
        localIp.setText(ip); networkType.setText(ni.type); packetLoss.setText(String.format(Locale.US, "%.1f%%", attempts == 0 ? 0 : (attempts - successes) * 100.0 / attempts));
        jitter.setText(String.format(Locale.US, "%.1f ms", successes > 1 ? jitterSum * 1.0 / (successes - 1) : 0));
        linkSpeed.setText(ni.linkMbps > 0 ? ni.linkMbps + " Mbit/s" : "–"); ramUsage.setText(ram + "%"); uptime.setText(formatUptime(SystemClock.elapsedRealtime()));
        graph.addValue(ping);
    }

    private NetworkInfo getNetworkInfo() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE); Network n = cm.getActiveNetwork(); NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
        if (c == null) return new NetworkInfo(getString(R.string.offline), 0);
        String type = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" : c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile" : c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ? "VPN" : "Network";
        return new NetworkInfo(type, c.getLinkDownstreamBandwidthKbps() / 1000);
    }

    private String findLocalIp() {
        try { for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) for (InetAddress address : Collections.list(ni.getInetAddresses())) if (!address.isLoopbackAddress() && address instanceof Inet4Address) return address.getHostAddress(); } catch (Exception ignored) {}
        return "–";
    }

    private void togglePause() { paused = !paused; pauseButton.setText(paused ? R.string.resume : R.string.pause); if (paused) status.setText(R.string.paused); }
    private void toggleLanguage() {
        String next = getResources().getConfiguration().getLocales().get(0).getLanguage().equals("de") ? "en" : "de";
        getSharedPreferences("settings", MODE_PRIVATE).edit().putString("language", next).apply();
        recreate();
    }
    private void resetStats() { attempts = successes = maxPing = sumPing = jitterSum = previousPing = peakDown = peakUp = 0; minPing = Long.MAX_VALUE; graph.reset(); pingDetail.setText(getString(R.string.waiting)); }
    private void showLicense() { new AlertDialog.Builder(this).setTitle(R.string.license_title).setMessage(R.string.license_text).setPositiveButton(R.string.close, null).show(); }

    private LinearLayout metricCard(int title, int accent) { LinearLayout box = panel(); GradientDrawable bg = round(SURFACE, 18); bg.setStroke(dp(1), Color.rgb(40, 52, 72)); box.setBackground(bg); TextView t = label(getString(title), 9, accent, true); box.addView(t); return box; }
    private LinearLayout panel() { LinearLayout box = column(); box.setPadding(dp(13), dp(13), dp(13), dp(13)); box.setBackground(round(SURFACE, 18)); return box; }
    private TextView sectionTitle(int id) { TextView t = label(getString(id), 10, MUTED, true); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(8); t.setLayoutParams(p); return t; }
    private TextView infoLine(LinearLayout parent, int labelId) { LinearLayout line = row(); TextView left = label(getString(labelId), 10, MUTED, false); TextView value = label("–", 10, TEXT, true); value.setGravity(Gravity.END); line.addView(left, weight()); line.addView(value, weight()); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(30)); parent.addView(line, p); return value; }
    private void infoLineStatic(LinearLayout parent, int id, String value) { TextView v = infoLine(parent, id); v.setText(value); }
    private TextView valueText(String s) { TextView t = label(s, 19, TEXT, true); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(7); t.setLayoutParams(p); return t; }
    private TextView detailText(String s) { TextView t = label(s, 8, MUTED, false); t.setSingleLine(true); return t; }
    private TextView action(String s) { TextView t = label(s, 10, TEXT, true); t.setGravity(Gravity.CENTER); t.setBackground(round(SURFACE_2, 13)); return t; }
    private TextView label(String s, float sp, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0, -2, 1); }
    private LinearLayout.LayoutParams cardWeight(int left, int weight) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, weight); p.leftMargin = left; return p; }
    private LinearLayout.LayoutParams buttonParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(74), dp(38)); p.leftMargin = dp(7); return p; }
    private LinearLayout.LayoutParams smallButtonParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(58), dp(38)); p.leftMargin = dp(7); return p; }
    private LinearLayout.LayoutParams size(int w, int h) { return new LinearLayout.LayoutParams(dp(w), dp(h)); }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private String formatRate(long bytes) { double bits = bytes * 8.0; if (bits >= 1e9) return String.format(Locale.US, "%.2f Gbit/s", bits / 1e9); if (bits >= 1e6) return String.format(Locale.US, "%.1f Mbit/s", bits / 1e6); if (bits >= 1e3) return String.format(Locale.US, "%.0f Kbit/s", bits / 1e3); return (long)bits + " bit/s"; }
    private String formatUptime(long ms) { long minutes = ms / 60000, days = minutes / 1440, hours = (minutes / 60) % 24; return days > 0 ? days + "d " + hours + "h" : String.format(Locale.US, "%02d:%02d", hours, minutes % 60); }

    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }
    private static final class NetworkInfo { final String type; final int linkMbps; NetworkInfo(String type, int linkMbps){ this.type = type; this.linkMbps = linkMbps; } }
}
