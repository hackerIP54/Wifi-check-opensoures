/*
 * STARCODE LiveNet Monitor
 * Copyright (C) 2026 starcode-bom & hackerIP54
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.starcode.livenet;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public final class GraphView extends View {
    private final List<Long> values = new ArrayList<>();
    private final Paint grid = new Paint(1);
    private final Paint line = new Paint(1);
    private final Paint fill = new Paint(1);

    public GraphView(Context context) {
        super(context);
        grid.setColor(Color.rgb(46, 58, 78));
        grid.setStrokeWidth(dp(1));
        line.setColor(Color.rgb(68, 224, 164));
        line.setStrokeWidth(dp(2.5f));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setColor(Color.argb(35, 68, 224, 164));
        fill.setStyle(Paint.Style.FILL);
    }

    public synchronized void addValue(long value) {
        if (values.size() == 60) values.remove(0);
        values.add(value);
        postInvalidate();
    }

    public synchronized void reset() {
        values.clear();
        postInvalidate();
    }

    @Override protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        for (int i = 1; i < 5; i++) {
            float y = h * i / 5f;
            canvas.drawLine(0, y, w, y, grid);
        }
        if (values.size() < 2) return;
        long max = 100;
        for (long value : values) if (value >= 0 && value > max) max = value;
        max = (long)(max * 1.2);
        Path stroke = new Path();
        Path area = new Path();
        boolean started = false;
        for (int i = 0; i < values.size(); i++) {
            long value = values.get(i);
            if (value < 0) { started = false; continue; }
            float x = values.size() == 1 ? 0 : w * i / 59f;
            float y = h - (h * value / max);
            if (!started) { stroke.moveTo(x, y); area.moveTo(x, h); area.lineTo(x, y); started = true; }
            else { stroke.lineTo(x, y); area.lineTo(x, y); }
        }
        if (started) { area.lineTo(w, h); area.close(); canvas.drawPath(area, fill); }
        canvas.drawPath(stroke, line);
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
}
